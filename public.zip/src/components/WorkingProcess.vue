<template>
  <section class="working-process-section">
    <div class="container">
      <div class="row">
        <div class="col-12" data-aos="fade-up" data-aos-delay="300">
          <div class="section-title process text-center pb-100">
            <div class="icon">
              <img src="assets/images/icon/pencile.png" alt="Icon_not_found" />
            </div>
            <h3 class="title">Working Process</h3>
            <span class="hr-secodary"></span>
          </div>
        </div>
      </div>

      <div class="row working-process mb-n4">
        <!-- working-process-list start -->
        <div
          class="col-lg-3 col-sm-6 working-process-list mb-4"
          data-aos="fade-up"
          data-aos-delay="400"
        >
          <img
            class="arrow-shape"
            src="assets/images/working/arrow-shape1.png"
            alt="images_not_found"
          />
          <div class="icon">
            <img src="assets/images/working/1.png" alt="images_not_found" />
          </div>
          <h4 class="title">Idea Generation</h4>
        </div>
        <!-- working-process-list end -->
         <!-- working-process-list start -->
        <div
          class="col-lg-3 col-sm-6 working-process-list mb-4"
          data-aos="fade-up"
          data-aos-delay="600"
        >
          <img
            class="arrow-shape"
            src="assets/images/working/arrow-shape1.png"
            alt="images_not_found"
          />
          <div class="icon">
            <img src="assets/images/working/3.png" alt="images_not_found" />
          </div>
          <h4 class="title">Project Research</h4>
        </div>
        <!-- working-process-list end -->
        <!-- working-process-list start -->
        <div
          class="col-lg-3 col-sm-6 working-process-list mb-4"
          data-aos="fade-up"
          data-aos-delay="500"
        >
          <img
            class="arrow-shape"
            src="assets/images/working/arrow-shape2.png"
            alt="images_not_found"
          />
          <div class="icon">
            <img src="assets/images/working/2.png" alt="images_not_found" />
          </div>
          <h4 class="title">Working Plan</h4>
        </div>
        <!-- working-process-list end -->
       
        <!-- working-process-list start -->
        <div
          class="col-lg-3 col-sm-6 working-process-list mb-4"
          data-aos="fade-up"
          data-aos-delay="700"
        >
          <div class="icon">
            <img src="assets/images/working/4.png" alt="images_not_found" />
          </div>
          <h4 class="title">Project Launch</h4>
        </div>
        <!-- working-process-list end -->
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style scoped>

</style>
