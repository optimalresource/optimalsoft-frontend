<template>
  <section class="faq-section">
    <img src="assets/images/faq/bg.png" alt="images-not_found" class="faq-bg" />
    <div class="container">
      <div class="row mb-n7">
        <div class="col-xl-6 mb-7">
          <div class="faq-image" data-aos="zoom-in" data-aos-delay="100">
            <img src="assets/images/faq/1.png" alt="images_not_found" />
          </div>
        </div>
        <div class="col-xl-6 mb-7">
          <div class="faq-content">
            <div class="section-title primary">
              <h5 class="sub-title">// FAQ.</h5>
              <h3 class="title">Frequiently Asked Question.</h3>
              <span class="hr-primary mt-4"></span>
            </div>
            <div class="accordion" id="accordionExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                  <button
                    class="accordion-button"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseOne"
                    aria-expanded="true"
                    aria-controls="collapseOne"
                  >
                    <span>What do I need to know before contacting you?</span>
                  </button>
                </h2>
                <div
                  id="collapseOne"
                  class="accordion-collapse collapse show"
                  aria-labelledby="headingOne"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <p>
                      Well, the most important thing to know is what you want to
                      accomplish. Why do you need the software? What should it
                      do? Having a clear vision of what exactly you want in mind
                      is crucial when ordering a software application. You don't
                      want to spend many months developing it with us without
                      being sure what you needWell, the most important thing to
                      know is what do you want to accomplish. Why do I need this
                      software? What for? What should it do? Having a clear
                      vision in mind is crucial when ordering a software
                      application. You don't want to spend many months
                      developing it with us without being sure what you need.
                    </p>
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingTwo">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseTwo"
                    aria-expanded="false"
                    aria-controls="collapseTwo"
                  >
                    <span
                      >Should I create a mobile or a web app for my
                      product?</span
                    >
                  </button>
                </h2>
                <div
                  id="collapseTwo"
                  class="accordion-collapse collapse"
                  aria-labelledby="headingTwo"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <p>
                      Both have their advantages and disadvantages. Mobile apps
                      are definitely more expensive but can provide you with
                      many more data gathering, monetization capabilities than
                      web applications. Progressive Web Apps are a good
                      compromise between a mobile and web app. But remember that
                      sooner or later you may need both mobile and web app and
                      when that moment comes we are here for you.
                    </p>
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingThree">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseThree"
                    aria-expanded="false"
                    aria-controls="collapseThree"
                  >
                    <span> How do I create a product with you?</span>
                  </button>
                </h2>
                <div
                  id="collapseThree"
                  class="accordion-collapse collapse"
                  aria-labelledby="headingThree"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <p>
                      If you have an idea contact us by our online form, e-mail
                      or phone. We'll meet and talk it over. Do well to prepare
                      as much info about your idea as possible, it will make the
                      meeting easier and benefit future cooperation.
                    </p>
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingFoure">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseFoure"
                    aria-expanded="false"
                    aria-controls="collapseFoure"
                  >
                    <span>
                      How much time will it take for you to make my app?</span
                    >
                  </button>
                </h2>
                <div
                  id="collapseFoure"
                  class="accordion-collapse collapse"
                  aria-labelledby="headingFoure"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <p>
                      To give you a more precise answer we must prepare a
                      project scope and create a budget in order for us to meet
                      up with the said date. We would give you a breakdown of
                      every process and steps it would take to arrive at the
                      completion of the project. We shall tell you how much of
                      that scope can be completed within the budget and we'll be
                      able to estimate how long will it take after at least a
                      month of work. Nevertheless, if you're not happy with our
                      work after two weeks you can retract from the project with
                      no penalties, this is our trial period and we believe that
                      any reliable software house should give you one.
                    </p>
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="heading">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapsenine"
                    aria-expanded="false"
                    aria-controls="collapseFoure"
                  >
                    <span>
                      Why should I choose you and not hire my own software
                      development team?</span
                    >
                  </button>
                </h2>
                <div
                  id="collapsenine"
                  class="accordion-collapse collapse"
                  aria-labelledby="collapsenine"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <p>
                      Hiring your own software developers can be a really smart
                      choice, however, recruitment process is time-consuming and
                      the costs of keeping an in-house programming team are very
                      high. You'll probably need to employ your own software
                      engineers sooner or later but hiring us can help you save
                      a lot of money and time.
                    </p>
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="heading">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseEight"
                    aria-expanded="false"
                    aria-controls="collapseFoure"
                  >
                    <span> What happens after you finish my app?</span>
                  </button>
                </h2>
                <div
                  id="collapseEight"
                  class="accordion-collapse collapse"
                  aria-labelledby="collapseEight"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <p>
                      Hopefully the app is exactly what you dreamed of. But
                      apart from delivering a finished product, we are happy to
                      provide you with technical support and app maintenance
                      should you need it. After all, we know our work inside
                      out. Of course if you want to maintain the app by yourself
                      the source code and all technical data is at your
                      disposal, but even in that case, feel free to contact us
                      if you need any help.
                    </p>
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="heading">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseSeven"
                    aria-expanded="false"
                    aria-controls="collapseFoure"
                  >
                    <span> How do you guarantee product quality?</span>
                  </button>
                </h2>
                <div
                  id="collapseSeven"
                  class="accordion-collapse collapse"
                  aria-labelledby="collapseSeven"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <p>
                      We evaluate the result of our work so far after every two
                      weeks, we test our work (we conduct both development and
                      acceptance tests), we present it to you, we apply your
                      feedback so you know you get what you are paying for.
                    </p>
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="heading">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseSix"
                    aria-expanded="false"
                    aria-controls="collapseFoure"
                  >
                    <span>
                      What if I want to be involved in the app development
                      process, do you have a problem with that?</span
                    >
                  </button>
                </h2>
                <div
                  id="collapseSix"
                  class="accordion-collapse collapse"
                  aria-labelledby="collapseSix"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <p>
                      Not at all! We want you to be sure you'll receive the
                      product you desire. From the planning stage to each
                      finished version, we invite you to evaluate and improve
                      our work. Our philosophy is to work with the client, not
                      merely finish given tasks. We are always ready to listen
                      and communicate
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style></style>
