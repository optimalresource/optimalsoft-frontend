<template>
  <div>
    <!-- <Header /> -->
    <section class="bread-crumb-section">
      <img
        class="shape shape1"
        src="assets/images/bread/1.png"
        alt="images_not_found"
      />
      <img
        class="shape shape2"
        src="assets/images/bread/2.png"
        alt="images_not_found"
      />
      <div class="container">
        <div class="row">
          <div class="col-12">
            <h2 class="title text-center">Service Details</h2>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb justify-content-center">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">
                  <span>Service Details</span>
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section>

    <!-- bread crumb section end -->

    <!-- service carousel start -->
    <!-- service carousel end -->

    <!-- service details start -->
    <section class="service-details-section mt-5 pt-5 pb-5">
      <div class="container">
        <div class="service-details">
          <div class="service-details-list">
            <div class="row mb-n7">
              <div class="col-lg-7 mb-7">
                <h2 class="title">WHY CHOOSE US</h2>
                <p>
                  Dedicated customer support: our team of dedicated customer
                  Support reps interacts with customers on a variety of channels
                  such as phone, email, and social media, and ensures that all
                  valid customer concerns are being dealt with immediately. We
                  focus on improving the intersection between customer
                  experience and the product we offer. The support we offer
                  involves technical problem solving, troubleshooting, and
                  finding new solutions and answers.
                </p>
                <p>
                  Professional Team Member: we are composed of professionals
                  from the fields of technology, who have a passion and
                  dedication to create sustainable and competitively top quality
                  solutions for everyone. We are highly innovative: we are
                  original and creative in thinking. We introduce new ways of
                  design that are not conventional but comes with a touch of
                  excellence and beauty to meet and exceed customer’s
                  requirement and for the maximum satisfaction of the general
                  public and users of our products.
                </p>
              </div>
              <div class="col-lg-5 mb-7">
                <img
                  src="assets/images/service-details/1.png"
                  alt="images-not_found"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer class="footer">
      <div class="copy-right-section">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <p>
                Copyright &copy;
                <span id="currentYear"></span>
                Made With
                <i class="icofont-heart"></i>
                By
                <a href="/">Optimalsoft</a>
                All Rights Reserved
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- <Footer /> -->
  </div>
</template>

<script>
// import Footer from "./Footer.vue";
// import Header from "@/components/Header.vue";
// import Footer from "@/components/Footer.vue";
export default {
  components: {
    // Footer,
    // Header,
    // Footer,
  },
};
</script>

<style></style>
