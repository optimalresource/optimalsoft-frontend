<template>
  <section class="service-section section-pb-150">
    <div class="container">
      <div class="row">
        <div class="col-12" data-aos="fade-up" data-aos-delay="200">
          <div class="section-title primary text-center pb-100">
            <div class="icon">
              <img src="assets/images/icon/sharing.png" alt="Icon_not_found" />
            </div>
            <h3 class="title">What We Offer</h3>
            <span class="hr-secodary"></span>
          </div>
        </div>
      </div>
      <div class="row mb-n7">
        <!-- service-card satrt -->
        <div class="col-md-6 mb-7" data-aos="fade-up" data-aos-delay="500">
          <div class="service-card">
            <img
              class="line"
              src="assets/images/service/line-one.png"
              alt="images_not_found"
            />
            <div class="service-icon">
              <div class="roted-around dagnger">
                <span></span>
              </div>
              <img src="assets/images/icon/marketing.png" alt="" />
            </div>
            <div class="service-content">
              <h4 class="title">Marketing Automation</h4>
              <p>
                Lorem Ipsum is simply dummy text of the ipsum has been the
                industry standard ever printer specimen book.
              </p>
              <a href="case-details.html" class="btn btn-danger">Details +</a>
            </div>
          </div>
        </div>
        <!-- service-card end -->
        <!-- service-card satrt -->
        <div class="col-md-6 mb-7" data-aos="fade-up" data-aos-delay="1000">
          <div class="service-card">
            <img
              class="line"
              src="assets/images/service/line-two.png"
              alt="images_not_found"
            />
            <div class="service-icon">
              <div class="roted-around warning">
                <span></span>
              </div>
              <img src="assets/images/icon/analytics.png" alt="" />
            </div>
            <div class="service-content">
              <h4 class="title">SEO Consultancy</h4>
              <p>
                Lorem Ipsum is simply dummy text of the ipsum has been the
                industry standard ever printer specimen book.
              </p>
              <a href="service-details.html" class="btn btn-warning"
                >Details +</a
              >
            </div>
          </div>
        </div>
        <!-- service-card end -->
        <!-- service-card satrt -->
        <div class="col-md-6 mb-7" data-aos="fade-up" data-aos-delay="1500">
          <div class="service-card">
            <img
              class="line"
              src="assets/images/service/line-three.png"
              alt="images_not_found"
            />
            <div class="service-icon">
              <div class="roted-around primary">
                <span></span>
              </div>
              <img src="assets/images/icon/connect.png" alt="" />
            </div>
            <div class="service-content">
              <h4 class="title">Pay Per Click Advertising</h4>
              <p>
                Lorem Ipsum is simply dummy text of the ipsum has been the
                industry standard ever printer specimen book.
              </p>
              <a href="service-details.html" class="btn btn-primary"
                >Details +</a
              >
            </div>
          </div>
        </div>
        <!-- service-card end -->
        <!-- service-card satrt -->
        <div class="col-md-6 mb-7" data-aos="fade-up" data-aos-delay="2000">
          <div class="service-card">
            <img
              class="line"
              src="assets/images/service/line-foure.png"
              alt="images_not_found"
            />
            <div class="service-icon">
              <div class="roted-around secondary">
                <span></span>
              </div>
              <img src="assets/images/icon/document.png" alt="" />
            </div>
            <div class="service-content">
              <h4 class="title">Marketing Automation</h4>
              <p>
                Lorem Ipsum is simply dummy text of the ipsum has been the
                industry standard ever printer specimen book.
              </p>
              <a href="case-details.html" class="btn btn-info text-white"
                >Details +</a
              >
            </div>
          </div>
        </div>
        <!-- service-card end -->
        <!-- <div class="col-12 mb-7 mt-7" data-aos="fade-up" data-aos-delay="1500">
          <div class="call-to-action text-center">
            <a href="/service" class="btn btn-warning"
              >All Services <i class="icofont-rounded-double-right"></i
            ></a>
          </div>
        </div> -->
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style scoped>
.service-card {
  display: flex !important;
  position: relative !important;
  background: #18329f !important;
  padding: 40px 40px 40px 50px !important;
  border-radius: 15px !important;
  color: antiquewhite;
}
.service-card h4 {
  color: antiquewhite;
}
</style>
