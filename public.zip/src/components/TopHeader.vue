<template>
  <div class="modal offcanvas-modal fade" id="offcanvas-modal">
    <div class="modal-dialog offcanvas-dialog">
      <div class="modal-content">
        <div class="modal-header offcanvas-header">
          <button
            type="button"
            class="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
          ></button>
        </div>
        <!-- offcanvas-form-wrap start -->
        <!-- <div class="offcanvas-form-wrap">
          <form action="#" class="offcanvas-form position-relative">
            <input
              class="form-control"
              type="text"
              placeholder="Enter your search key ... "
            />
            <button class="btn btn-primary">search</button>
          </form>
        </div> -->
        <!-- offcanvas-form-wrap end -->
        <!-- offcanvas-menu start -->
        <nav id="offcanvas-menu" class="offcanvas-menu">
          <ul>
            <li>
              <a href="/">Home</a>
              <!-- add your sub menu here -->
            </li>
            <li>
              <a href="/services">Services</a>
            </li>
            <li><a href="about-us.html">about us</a></li>
            <li><a href="faq.html">faq</a></li>
            <!-- <li>
              <a href="case-details.html">Case Studies</a>
            </li>
            <li>
              <a href="#?">Blog</a>
              <ul>
                <li>
                  <a href="blog-details.html">blog details</a>
                </li>
                <li>
                  <a href="blog-grid-3-column.html">blog grid 3 column</a>
                </li>
                <li>
                  <a href="blog-left-sidebar.html">blog left sidebar</a>
                </li>
                <li>
                  <a href="blog-right-sidebar.html">blog right sidebar</a>
                </li>
              </ul>
            </li> -->
            <!-- <li>
              <a href="javascript:void(0)">Pages</a>
              <ul>
                <li><a href="about-us.html">about us</a></li>
                <li><a href="faq.html">faq</a></li>
                <li><a href="404.html">404 not found!</a></li>
              </ul>
            </li> -->
            <li>
              <a href="/contact">Contact Us</a>
            </li>
          </ul>

          <div class="offcanvas-social">
            <ul>
              <li>
                <a href="https://www.facebook.com/optimalsoftcom"><i class="icofont-facebook"></i></a>
              </li>
              <li>
                <a href="#"><i class="icofont-twitter"></i></a>
              </li>
              <li>
                <a href="#"><i class="icofont-skype"></i></a>
              </li>
              <li>
                <a href="#"><i class="icofont-linkedin"></i></a>
              </li>
            </ul>
          </div>
        </nav>
        <!-- offcanvas-menu end -->

        <!-- <p class="text-gradient mt-3">Let us grow your website traffic.</p> -->
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
