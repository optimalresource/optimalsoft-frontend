<template>
  <div class="case-studies-section">
    <div class="container">
      <div class="row">
        <div class="col-12" data-aos="fade-up" data-aos-delay="100">
          <div class="section-title primary text-center pb-100">
            <div class="icon">
              <img src="assets/images/icon/webpack.png" alt="Icon_not_found" />
            </div>
            <h3 class="title">Some Case Studies</h3>
            <span class="hr-secodary"></span>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="case-carousel">
            <div class="swiper-container">
              <div class="swiper-wrapper">
                <!-- single slide start -->
                <div
                  class="swiper-slide"
                  data-aos="fade-up"
                  data-aos-delay="900"
                >
                  <div class="case-card">
                    <div class="thumb">
                      <a href="case-details.html">
                        <img
                          class="case-shap case-shape1"
                          src="assets/images/case/shape1.png"
                          alt="images_not_found" />
                        <img
                          class="case-shape case-shape2"
                          src="assets/images/case/shape2.png"
                          alt="images_not_found" />

                        <img
                          class="case-image"
                          src="assets/images/case/1.png"
                          alt="images_not_found"
                      /></a>
                    </div>
                    <div class="case-content">
                      <h3 class="title">
                        <a href="case-details.html">Marketing Automation</a>
                      </h3>
                      <p>Digital Strategy / Consulting</p>
                    </div>
                  </div>
                </div>
                <!-- single slide end -->
                <!-- single slide start -->
                <div
                  class="swiper-slide"
                  data-aos="fade-up"
                  data-aos-delay="600"
                >
                  <div class="case-card">
                    <div class="thumb">
                      <a href="case-details.html">
                        <img
                          class="case-shap case-shape1"
                          src="assets/images/case/shape1.png"
                          alt="images_not_found" />
                        <img
                          class="case-shape case-shape2"
                          src="assets/images/case/shape2.png"
                          alt="images_not_found" />

                        <img
                          class="case-image"
                          src="assets/images/case/2.png"
                          alt="images_not_found"
                      /></a>
                    </div>
                    <div class="case-content">
                      <h3 class="title">
                        <a href="case-details.html">Digital Consulting</a>
                      </h3>
                      <p>Marketing / Automation</p>
                    </div>
                  </div>
                </div>
                <!-- single slide end -->
                <!-- single slide start -->
                <div
                  class="swiper-slide"
                  data-aos="fade-up"
                  data-aos-delay="300"
                >
                  <div class="case-card">
                    <div class="thumb">
                      <a href="case-details.html">
                        <img
                          class="case-shap case-shape1"
                          src="assets/images/case/shape1.png"
                          alt="images_not_found" />
                        <img
                          class="case-shape case-shape2"
                          src="assets/images/case/shape2.png"
                          alt="images_not_found" />

                        <img
                          class="case-image"
                          src="assets/images/case/3.png"
                          alt="images_not_found"
                      /></a>
                    </div>
                    <div class="case-content">
                      <h3 class="title">
                        <a href="case-details.html">Marketing Automation</a>
                      </h3>
                      <p>Digital Strategy / Consulting</p>
                    </div>
                  </div>
                </div>
                <!-- single slide end -->
              </div>
              <!-- If we need navigation buttons -->
              <div class="container case-carousel-navigation">
                <div class="case-carousel swiper-button-prev">
                  <i class="icofont-rounded-double-left"></i>
                </div>
                <div class="case-carousel swiper-button-next">
                  <i class="icofont-rounded-double-right"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
