<template>
  <div
    class="brand-section section-pb-150"
    data-aos="fade-up"
    data-aos-delay="100"
  >
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="brand-card brand-carousel">
            <p class="text-center">
              Trusted by <span class="text-gradient">8,980+</span> of The
              World's Best Organization.
            </p>
            <div class="swiper-container">
              <div class="swiper-wrapper">
                <!-- single slide start -->
                <div class="swiper-slide">
                  <a class="brand-before" href="#"
                    ><img
                      src="assets/images/brand-logo/1.png"
                      alt="images-not_found"
                  /></a>
                  <a class="brand-after" href="#"
                    ><img
                      src="assets/images/brand-logo/1.1.png"
                      alt="images-not_found"
                  /></a>
                </div>
                <!-- single slide end -->
                <!-- single slide start -->
                <div class="swiper-slide">
                  <a class="brand-before" href="#"
                    ><img
                      src="assets/images/brand-logo/2.png"
                      alt="images-not_found"
                  /></a>
                  <a class="brand-after" href="#"
                    ><img
                      src="assets/images/brand-logo/2.1.png"
                      alt="images-not_found"
                  /></a>
                </div>
                <!-- single slide end -->
                <!-- single slide start -->
                <div class="swiper-slide">
                  <a class="brand-before" href="#"
                    ><img
                      src="assets/images/brand-logo/3.png"
                      alt="images-not_found"
                  /></a>
                  <a class="brand-after" href="#"
                    ><img
                      src="assets/images/brand-logo/3.1.png"
                      alt="images-not_found"
                  /></a>
                </div>
                <!-- single slide end -->
                <!-- single slide start -->
                <div class="swiper-slide">
                  <a class="brand-before" href="#"
                    ><img
                      src="assets/images/brand-logo/4.png"
                      alt="images-not_found"
                  /></a>
                  <a class="brand-after" href="#"
                    ><img
                      src="assets/images/brand-logo/4.1.png"
                      alt="images-not_found"
                  /></a>
                </div>
                <!-- single slide end -->
                <!-- single slide start -->
                <div class="swiper-slide">
                  <a class="brand-before" href="#"
                    ><img
                      src="assets/images/brand-logo/5.png"
                      alt="images-not_found"
                  /></a>
                  <a class="brand-after" href="#"
                    ><img
                      src="assets/images/brand-logo/5.1.png"
                      alt="images-not_found"
                  /></a>
                </div>
                <!-- single slide end -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped></style>
