<template>
  <section class="blog-section">
    <div class="container">
      <div class="row mb-n7">
        <div class="col-lg-6 mb-7">
          <div
            class="section-title text-center text-lg-start primary"
            data-aos="fade-up"
            data-aos-delay="100"
          >
            <h3 class="title">Latest News From Our Blog.</h3>
            <span class="hr-primary mt-4"></span>
          </div>

          <div class="blog-card" data-aos="fade-up" data-aos-delay="600">
            <div class="thumb">
              <a href="blog-details.html"
                ><img src="assets/images/blog/1.png" alt="images-not_found"
              /></a>
            </div>
            <div class="content">
              <p>
                By Admin / 12 January, 2021 / <span>Digital Marketing.</span>
              </p>
              <h3 class="title">
                <a href="blog-details.html"
                  >The Step-by-Step Guide to Improving Your Google Rankings.</a
                >
              </h3>
            </div>
          </div>
        </div>
        <div class="col-lg-6 mb-7">
          <div class="blog-meta-cards">
            <!-- blog-meta-card  -->
            <div class="blog-meta-card" data-aos="fade-up" data-aos-delay="300">
              <div class="thumb">
                <img src="assets/images/blog/2.png" alt="images-not_found" />
              </div>
              <div class="content">
                <p>
                  By Admin / 12 January, 2021 /
                  <span>Digital Marketing.</span>
                </p>
                <h3 class="title">
                  <a href="blog-details.html">
                    What's the Current Job Market for Seo Professionals Like?
                  </a>
                </h3>
              </div>
            </div>
            <!-- blog-meta-card  end-->
            <!-- blog-meta-card  -->
            <div
              class="blog-meta-card"
              data-aos="fade-up"
              data-aos-delay="1200"
            >
              <div class="thumb">
                <img src="assets/images/blog/3.png" alt="images-not_found" />
              </div>
              <div class="content">
                <p>
                  By Admin / 12 January, 2021 /
                  <span>Digital Marketing.</span>
                </p>
                <h3 class="title">
                  <a href="blog-details.html">
                    Addicted to Seo? Us Too. 6 Reasons We Just Can't Stop.
                  </a>
                </h3>
              </div>
            </div>
            <!-- blog-meta-card  end-->
            <!-- blog-meta-card  -->
            <div
              class="blog-meta-card"
              data-aos="fade-up"
              data-aos-delay="1500"
            >
              <div class="thumb">
                <img src="assets/images/blog/4.png" alt="images-not_found" />
              </div>
              <div class="content">
                <p>
                  By Admin / 12 January, 2021 /
                  <span>Digital Marketing.</span>
                </p>
                <h3 class="title">
                  <a href="blog-details.html">
                    Why You Should Spend More Time Thinking About Seo.
                  </a>
                </h3>
              </div>
            </div>
            <!-- blog-meta-card  end-->
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style></style>
