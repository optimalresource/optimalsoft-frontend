<template>
  <section class="testimonial-section">
    <div class="container">
      <div class="row">
        <div class="col-12" data-aos="fade-up" data-aos-delay="100">
          <div class="section-title primary text-center pb-100">
            <div class="icon">
              <img
                src="assets/images/icon/testimonial.png"
                alt="Icon_not_found"
              />
            </div>
            <h3 class="title">Amazing Team Members</h3>
            <span class="hr-secodary"></span>
          </div>
        </div>
      </div>
      <div class="row position-relative">
        <div class="clients">
          <img
            src="assets/images/testimonial/joe.png"
            alt="images-not_found"
            class="client"
          />
          <img
            src="assets/images/testimonial/sasu.png"
            alt="images-not_found"
            class="client"
          />
          <img
            src="assets/images/testimonial/ify.png"
            alt="images-not_found"
            class="client"
          />
          <img
            src="assets/images/testimonial/gift.png"
            alt="images-not_found"
            class="client"
          />
        </div>
        <div class="col-12 mx-auto">
          <div class="testimonial-content position-relative">
            <img
              class="shape"
              src="assets/images/testimonial/shape.png"
              alt="images-not_found"
            />
            <div class="testimonial-carousel">
              <div class="swiper-container">
                <div class="swiper-wrapper">
                  <!-- swiper-slide start -->
                  <div
                    class="swiper-slide"
                    data-aos="fade-up"
                    data-aos-delay="300"
                  >
                    <div class="profile-wrap">
                      <img
                        class="testimonial-profile"
                        src="assets/images/testimonial/joe.png"
                        alt="images-not_found"
                      />
                      <span class="quote">“</span>
                    </div>

                    <p>
                      Joseph is the CEO of Optimalsoft Limited, a goal-oriented
                      software development firm that strives to demonstrate the
                      infiniteness and beauty of technology in improving human
                      existence and well-being. He is also the co-founder and
                      Chief Technology Officer of Apeirox, an Ecommerce platform
                      that seeks to bridge the gap between local and
                      international trade. He has designed a lot of web apps for
                      large technology companies such as MTN which he also
                      manages.
                    </p>
                    <h5 class="sub-title">Joseph Okafor</h5>
                    <span class="designation">CEO</span>
                  </div>
                  <!-- swiper-slide end -->
                  <!-- swiper-slide start -->
                  <div
                    class="swiper-slide"
                    data-aos="fade-up"
                    data-aos-delay="300"
                  >
                    <div class="profile-wrap">
                      <img
                        class="testimonial-profile"
                        src="assets/images/testimonial/sasu.png"
                        alt="images-not_found"
                      />
                      <span class="quote">“</span>
                    </div>

                    <p>
                      Osasumwen is a frontend developer and graphic designer in
                      Optimalsoft. He holds a BSc in Medical Physiology. He is
                      also part of the developers team of Apeirox an Ecommerce
                      platform that seeks to bridge the gap between local and
                      international trade. He has been a part of a variety of
                      initiatives, including web application Landearn, Bumasys,
                      MyJobDesk, and other continuing initiatives.
                    </p>
                    <h5 class="sub-title">Mumen Osasumwen</h5>
                    <span class="designation">Ui/Ux designer</span>
                  </div>
                  <!-- swiper-slide end -->
                  <!-- swiper-slide start -->
                  <div
                    class="swiper-slide"
                    data-aos="fade-up"
                    data-aos-delay="300"
                  >
                    <div class="profile-wrap">
                      <img
                        class="testimonial-profile"
                        src="assets/images/testimonial/ify.png"
                        alt="images-not_found"
                      />
                      <span class="quote">“</span>
                    </div>

                    <p>
                      Ifeanyi is a backend developer at Optimalsoft. He is also
                      part of the developers team of Apeirox an Ecommerce
                      platform that seeks to bridge the gap between local and
                      international trade. He has been a part of a variety of
                      initiatives, including web application development for
                      Landearn, Bumasys, MyJobDesk, and other continuing
                      initiatives.
                    </p>
                    <h5 class="sub-title">Ifeanyi Kalu</h5>
                    <span class="designation">Core backend developer</span>
                  </div>
                  <!-- swiper-slide end -->

                  <!-- swiper-slide start -->
                  <div
                    class="swiper-slide"
                    data-aos="fade-up"
                    data-aos-delay="300"
                  >
                    <div class="profile-wrap">
                      <img
                        class="testimonial-profile"
                        src="assets/images/testimonial/gift.png"
                        alt="images-not_found"
                      />
                      <span class="quote">“</span>
                    </div>

                    <p>
                      Gift is Frontend and content developer at Optimalsoft. She
                      holds a BSc in Computer Science. She is also part of the
                      developers’ team for Apeirox, an Ecommerce platform that
                      seeks to bridge the gap between local and international
                      trade. She has been part of a variety of initiatives,
                      including web application development and content creation
                      for Landearn, Bumasys, and other upcoming projects
                    </p>
                    <h5 class="sub-title">Gift Kanu</h5>
                    <span class="designation">
                      Content Creator and Social media Manager</span
                    >
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style></style>
