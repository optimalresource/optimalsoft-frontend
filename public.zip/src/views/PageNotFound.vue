<template>
  <section class="page-not-found-section section-padding-y-200">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="col-lg-8 col-xl-6 mx-auto mb-7">
            <div class="page-not-found-content">
              <h3 class="title">
                Sorry! <small>This Page is Not Found.</small>
              </h3>
            </div>
          </div>
          <ul class="page-not-found">
            <li class="page-not-found-item">
              <img
                src="assets/images/page-not-found/1.png"
                alt="images_not_found"
              />
              <span class="number">4</span>
            </li>
            <li class="page-not-found-item">
              <img
                src="assets/images/page-not-found/2.png"
                alt="images_not_found"
              />
              <span class="number">0</span>
            </li>
            <li class="page-not-found-item">
              <img
                src="assets/images/page-not-found/3.png"
                alt="images_not_found"
              />
              <span class="number">4</span>
            </li>
          </ul>
          <a href="/" class="btn btn-primary col-md-3 col-sm-12 mt-4 mb-4">
            <i class="icofont-rounded-double-left"></i> Back To Home</a
          >
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style scoped>
.section-padding-y-200 {
  padding: 0;
}
</style>
